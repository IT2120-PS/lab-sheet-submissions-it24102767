setwd("C:\\Users\\ASUS\\OneDrive\\Desktop\\PS")

#Q1
punif(10, min=0, max=40, lower.tail=FALSE) - punif(25, min=0, max=40, lower.tail=FALSE)

#Q2
pexp(0, rate=1/3, lower.tail=FALSE) - pexp(2, rate=1/3, lower.tail=FALSE)

#Q3.1
pnorm(130, mean=100, sd=15, lower.tail=FALSE)

#Q3.2
qnorm(0.05, mean=100, sd=15, lower.tail=FALSE)

